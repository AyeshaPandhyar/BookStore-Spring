package com.cg.bookstore.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	String  email ;
	String name,password, confirmpassword , address,city,country,zipcode,number;
    


	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(String name, String email, String password, String confirmpassword , String address, String city, String country,
			String zipcode, String number) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.confirmpassword =  confirmpassword ;
		this.address = address;
		this.city = city;
		this.country = country;
		this.zipcode = zipcode;
		this.number = number;	}

	
	
	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number ) {
		this.number = number;
	}

	@Override
	public String toString() {
		return "Customer [email=" + email + ", name=" + name + ", password=" + password + ", confirmpassword="
				+ confirmpassword + ", address=" + address + ", city=" + city + ", country=" + country + ", zipcode="
				+ zipcode + ", number=" + number + "]";
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
