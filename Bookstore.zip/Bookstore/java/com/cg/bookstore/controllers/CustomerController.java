package com.cg.bookstore.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.exceptions.* ;//CustomerAlreadyExistsException;
import com.cg.bookstore.services.CustomerServices;
import com.cg.bookstore.services.CustomerServicesImpl;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerServicesImpl customerServices ; // = new CustomerServicesImpl() ;
	
	
	@RequestMapping(value = {"/addcustomer"},method= RequestMethod.POST ,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE )
	 public ResponseEntity<String> addcustomer(@ModelAttribute Customer customer) throws CustomerAlreadyExistsException{
		customer = customerServices.addCustomer(customer); 
		return new ResponseEntity<>("Customer Rigistered Succussfully" + customer.getEmail() , HttpStatus.OK ) ;
	}
		
	@RequestMapping(value = {"/findcustomer"} , method= RequestMethod.GET , produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> findcustomer(@RequestParam String email,@RequestParam String password) throws CustomerNotExistException {
		Customer customer = customerServices.findCustomer(email,password) ;
	   return new ResponseEntity<Customer>(customer , HttpStatus.OK) ;
	}
	
	@RequestMapping(value= {"/editProfile"}, method = RequestMethod.PUT , consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE )  
	public ResponseEntity<Customer> editCustomer(@ModelAttribute Customer customer) { 
	Customer editedCustomer= customerServices.editCustomer(customer); 
		return new ResponseEntity<Customer>( editedCustomer , HttpStatus.OK) ; 
	}

		
	

}
