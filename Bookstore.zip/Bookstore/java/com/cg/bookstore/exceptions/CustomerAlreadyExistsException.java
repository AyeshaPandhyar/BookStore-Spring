package com.cg.bookstore.exceptions;


public class CustomerAlreadyExistsException extends Exception { 

	public CustomerAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerAlreadyExistsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CustomerAlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CustomerAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CustomerAlreadyExistsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
