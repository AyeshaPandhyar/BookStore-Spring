package com.cg.bookstore.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPageBeans {

	@FindBy(how=How.NAME,name="email")
	private WebElement email;
	
	@FindBy(how=How.NAME,name="name")
	private WebElement name;
	
	@FindBy(how=How.ID,id="password")
	private WebElement password;
	
	@FindBy(how=How.ID,id="confirmpassword")
	private WebElement confirmpassword;
	
	@FindBy(how=How.ID,id="number")
	private WebElement number;
	
	@FindBy(how=How.ID,id="address")
	private WebElement address;
	
	@FindBy(how=How.ID,id="city")
	private WebElement city;
	
	@FindBy(how=How.ID,id="zipcode")
	private WebElement zipcode;
	
	@FindBy(how=How.ID,id="country")
	private WebElement country;
	
	@FindBy(className="btn")
	private WebElement button;

	@FindBy(how=How.XPATH,xpath="//*[@id=\"js-flash-container\"]/div/div")
	private WebElement actualErrorMesssage;

	public void clickRegister() {
		button.submit();
	}
	
	
	public String getActualErrorMesssage() {
		return actualErrorMesssage.getText();
	}
//	public void setActualErrorMesssage(String actualErrorMesssage) {
//	this.actualErrorMesssage = actualErrorMesssage;
//}
		
	public String getEmail() {
		return email.getAttribute("value" );
	}	
	
	public void setEmail(String email) {
		 this.email.sendKeys(email);
	}

	public String getName() {
		  return name.getAttribute("value");
	}

	public void setName(String name) {
		 this.name.sendKeys(name);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public String getConfirmpassword() {
		return confirmpassword.getAttribute("value");
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword.sendKeys(confirmpassword); 
	}

	public String getNumber() {
		return number.getAttribute("value");
	}

	public void setNumber(String number) {
		this.number.sendKeys(number);;
	}

	public String getAddress() {
		return address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getCity() {
		return city.getAttribute("value");
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public String getZipcode() {
		return zipcode.getAttribute("value");
	}

	public void setZipcode(String zipcode) {
		this.zipcode.sendKeys(zipcode);
	}

	public String getCountry() {
		return country.getAttribute("value");
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	public String getButton() {
		return button.getAttribute("value");
	}

	public void setButton(String button) {
		this.button.sendKeys(button);
	}	

}	
	