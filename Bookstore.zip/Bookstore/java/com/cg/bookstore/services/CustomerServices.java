package com.cg.bookstore.services;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.exceptions.*;

public interface CustomerServices {
	
	public Customer addCustomer(Customer customer) throws CustomerAlreadyExistsException  ;
	public Customer findCustomer(String email, String password) throws CustomerNotExistException ;
	public Customer editCustomer(Customer customer) ;
	
}
