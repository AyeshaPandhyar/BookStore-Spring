package com.cg.bookstore.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.daoservices.CustomerDaoServices;
import com.cg.bookstore.exceptions.CustomerAlreadyExistsException;
import com.cg.bookstore.exceptions.CustomerNotExistException;

@Component("customerServices")
public class CustomerServicesImpl implements CustomerServices{

	@Autowired
	CustomerDaoServices customerDao ;

	@Override
	public Customer addCustomer(Customer customer) throws CustomerAlreadyExistsException {
		customerDao.findById(customer.getEmail()).orElseThrow(()-> new CustomerAlreadyExistsException("Customer already exixt")) ;
		customer=customerDao.save(customer);
		return customer;
	}

	@Override  //at the time of login
	public Customer findCustomer(String loginemail, String loginpassword) throws CustomerNotExistException {
		Customer customer1 = customerDao.findById(loginemail).orElseThrow(()-> new CustomerNotExistException("CUstomer Does not exist"));
		    //sign in
		return customer1 ;
		    	
	}    	
		    	

	@Override
	public Customer editCustomer(Customer customer) {
		return customerDao.save(customer) ;
	}



}
