package com.cg.bookstore.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.bookstore.pagebeans.RegistrationPageBeans;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	private WebDriver driver;
	private RegistrationPageBeans registrationPage;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
	}
	
	
	@Given("^user is accessing Registration Page on Browser$")
	public void user_is_accessing_Registration_Page_on_Browser() throws Throwable {
		driver = new ChromeDriver();
		driver.get("https://bookstore/registerCustomer");
		registrationPage = PageFactory.initElements(driver,RegistrationPageBeans.class);
	}

	@When("^user is trying to submit data without entering valid 'email'$")
	public void user_is_trying_to_submit_data_without_entering_valid_email() throws Throwable {
		registrationPage.setName("Ayesha");
		//registrationPage.setPassword("abcd");
		registrationPage.clickRegister() ; 
	}

	@Then("^'You have entered an invalid email! ' alert message is displayed$")
	public void you_have_entered_an_invalid_email_address_alert_message_is_displayed() throws Throwable {
		String expectedErrorMessage="You have entered an invalid email" ;
		Assert.assertEquals(expectedErrorMessage, registrationPage.getActualErrorMesssage());
	}

	@When("^user is trying submit data without entering 'name'$")
	public void user_is_trying_submit_data_without_entering_name() throws Throwable {
		//registrationPage.setName("Ayesha");
		registrationPage.setPassword("abcd");
		registrationPage.clickRegister() ; 
	}

	@Then("^'name should not be empty' alert message is displayed$")
	public void name_should_not_be_empty_alert_message_is_displayed() throws Throwable {
		String expectedErrorMessage="name should not be empty" ;
		Assert.assertEquals(expectedErrorMessage, registrationPage.getActualErrorMesssage());
	}

	@When("^user is trying submit data without entering valid 'password'$")
	public void user_is_trying_submit_data_without_entering_valid_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@Then("^'password must not be empty' alert message is displayed$")
	public void password_must_not_be_empty_alert_message_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    ///throw new PendingException();
	}

	@When("^user is trying submit data without entering valid 'number'$")
	public void user_is_trying_submit_data_without_entering_valid_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@Then("^'phoneNumber should not be empty' alert message is displayed$")
	public void phonenumber_should_not_be_empty_alert_message_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@When("^user is trying submit data without entering valid 'address'$")
	public void user_is_trying_submit_data_without_entering_valid_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // new PendingException();
	}

	@Then("^'address should not be empty ' alert message is displayed$")
	public void address_should_not_be_empty_alert_message_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@When("^user is trying submit data without entering valid 'city'$")
	public void user_is_trying_submit_data_without_entering_valid_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
	}

	@Then("^'Please Select city' alert message should display$")
	public void please_Select_city_alert_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // new PendingException();
	}

	@When("^user is trying submit data without entering valid 'zipCode'$")
	public void user_is_trying_submit_data_without_entering_valid_zipCode() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
	}

	@Then("^'ZIP code must have numeric characters only' alert message should display$")
	public void zip_code_must_have_numeric_characters_only_alert_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // new PendingException();
	}

	@When("^user is trying submit data without entering valid 'country'$")
	public void user_is_trying_submit_data_without_entering_valid_country() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@Then("^'Enter country' alert message should display$")
	public void enter_country_alert_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
	}

	@When("^user is trying to submit with valid set of details$")
	public void user_is_trying_to_submit_with_valid_set_of_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
	}

	@Then("^'Registration is successfull alert message should display'$")
	public void registration_is_successfull_alert_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}
	
	@After
	public void tearDownStepEnv() {
		driver.close();
	}


}
